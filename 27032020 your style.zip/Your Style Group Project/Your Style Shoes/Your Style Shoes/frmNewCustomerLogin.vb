﻿Public Class frmNewCustomerLogin

End Class