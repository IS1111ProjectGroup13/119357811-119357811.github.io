﻿Public Class frmCustomer
    Private Sub btnNewCustomer_Click(sender As Object, e As EventArgs) Handles btnNewCustomer.Click
        Me.Hide()
        frmNewCustomerLogin.Visible = True
    End Sub

    Private Sub btnExistingCustomer_Click(sender As Object, e As EventArgs) Handles btnExistingCustomer.Click
        Me.Hide()
        frmCustomerLogin.Visible = True
    End Sub
End Class