﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmNewCustomerLogin
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.pnlBlue = New System.Windows.Forms.Panel()
        Me.picLogo = New System.Windows.Forms.PictureBox()
        Me.pnlBlack = New System.Windows.Forms.Panel()
        Me.lblNewCustomerAccount = New System.Windows.Forms.Label()
        Me.lblFirstNameNewCust = New System.Windows.Forms.Label()
        Me.lblLastNameNewCust = New System.Windows.Forms.Label()
        Me.lblEmailNewCustomer = New System.Windows.Forms.Label()
        Me.lblUsernameNewCust = New System.Windows.Forms.Label()
        Me.btnCreateAccountCustomer = New System.Windows.Forms.Button()
        Me.txtFirstNameNewCust = New System.Windows.Forms.TextBox()
        Me.txtLastNameNewCust = New System.Windows.Forms.TextBox()
        Me.txtEmailNewCust = New System.Windows.Forms.TextBox()
        Me.txtUsernameNewCust = New System.Windows.Forms.TextBox()
        Me.lblPasswordNewCustomer = New System.Windows.Forms.Label()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.pnlBlue.SuspendLayout()
        CType(Me.picLogo, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'pnlBlue
        '
        Me.pnlBlue.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.pnlBlue.Controls.Add(Me.lblNewCustomerAccount)
        Me.pnlBlue.Controls.Add(Me.picLogo)
        Me.pnlBlue.Location = New System.Drawing.Point(0, -1)
        Me.pnlBlue.Name = "pnlBlue"
        Me.pnlBlue.Size = New System.Drawing.Size(433, 74)
        Me.pnlBlue.TabIndex = 0
        '
        'picLogo
        '
        Me.picLogo.Image = Global.Your_Style_Shoes.My.Resources.Resources.logo_your_style
        Me.picLogo.Location = New System.Drawing.Point(0, 3)
        Me.picLogo.Name = "picLogo"
        Me.picLogo.Size = New System.Drawing.Size(76, 61)
        Me.picLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.picLogo.TabIndex = 1
        Me.picLogo.TabStop = False
        '
        'pnlBlack
        '
        Me.pnlBlack.BackColor = System.Drawing.Color.Black
        Me.pnlBlack.Location = New System.Drawing.Point(0, 69)
        Me.pnlBlack.Name = "pnlBlack"
        Me.pnlBlack.Size = New System.Drawing.Size(433, 20)
        Me.pnlBlack.TabIndex = 1
        '
        'lblNewCustomerAccount
        '
        Me.lblNewCustomerAccount.AutoSize = True
        Me.lblNewCustomerAccount.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblNewCustomerAccount.Location = New System.Drawing.Point(77, 28)
        Me.lblNewCustomerAccount.Name = "lblNewCustomerAccount"
        Me.lblNewCustomerAccount.Size = New System.Drawing.Size(353, 25)
        Me.lblNewCustomerAccount.TabIndex = 2
        Me.lblNewCustomerAccount.Text = "Create New Customer Account"
        '
        'lblFirstNameNewCust
        '
        Me.lblFirstNameNewCust.AutoSize = True
        Me.lblFirstNameNewCust.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFirstNameNewCust.Location = New System.Drawing.Point(33, 116)
        Me.lblFirstNameNewCust.Name = "lblFirstNameNewCust"
        Me.lblFirstNameNewCust.Size = New System.Drawing.Size(98, 18)
        Me.lblFirstNameNewCust.TabIndex = 2
        Me.lblFirstNameNewCust.Text = "First Name"
        '
        'lblLastNameNewCust
        '
        Me.lblLastNameNewCust.AutoSize = True
        Me.lblLastNameNewCust.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblLastNameNewCust.Location = New System.Drawing.Point(34, 144)
        Me.lblLastNameNewCust.Name = "lblLastNameNewCust"
        Me.lblLastNameNewCust.Size = New System.Drawing.Size(97, 18)
        Me.lblLastNameNewCust.TabIndex = 3
        Me.lblLastNameNewCust.Text = "Last Name"
        '
        'lblEmailNewCustomer
        '
        Me.lblEmailNewCustomer.AutoSize = True
        Me.lblEmailNewCustomer.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblEmailNewCustomer.Location = New System.Drawing.Point(73, 178)
        Me.lblEmailNewCustomer.Name = "lblEmailNewCustomer"
        Me.lblEmailNewCustomer.Size = New System.Drawing.Size(52, 18)
        Me.lblEmailNewCustomer.TabIndex = 4
        Me.lblEmailNewCustomer.Text = "Email"
        '
        'lblUsernameNewCust
        '
        Me.lblUsernameNewCust.AutoSize = True
        Me.lblUsernameNewCust.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblUsernameNewCust.Location = New System.Drawing.Point(48, 215)
        Me.lblUsernameNewCust.Name = "lblUsernameNewCust"
        Me.lblUsernameNewCust.Size = New System.Drawing.Size(92, 18)
        Me.lblUsernameNewCust.TabIndex = 5
        Me.lblUsernameNewCust.Text = "Username"
        '
        'btnCreateAccountCustomer
        '
        Me.btnCreateAccountCustomer.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCreateAccountCustomer.Location = New System.Drawing.Point(82, 326)
        Me.btnCreateAccountCustomer.Name = "btnCreateAccountCustomer"
        Me.btnCreateAccountCustomer.Size = New System.Drawing.Size(115, 64)
        Me.btnCreateAccountCustomer.TabIndex = 6
        Me.btnCreateAccountCustomer.Text = "&Create New Account"
        Me.btnCreateAccountCustomer.UseVisualStyleBackColor = True
        '
        'txtFirstNameNewCust
        '
        Me.txtFirstNameNewCust.Location = New System.Drawing.Point(146, 112)
        Me.txtFirstNameNewCust.Name = "txtFirstNameNewCust"
        Me.txtFirstNameNewCust.Size = New System.Drawing.Size(100, 22)
        Me.txtFirstNameNewCust.TabIndex = 7
        '
        'txtLastNameNewCust
        '
        Me.txtLastNameNewCust.Location = New System.Drawing.Point(146, 140)
        Me.txtLastNameNewCust.Name = "txtLastNameNewCust"
        Me.txtLastNameNewCust.Size = New System.Drawing.Size(100, 22)
        Me.txtLastNameNewCust.TabIndex = 8
        '
        'txtEmailNewCust
        '
        Me.txtEmailNewCust.Location = New System.Drawing.Point(146, 177)
        Me.txtEmailNewCust.Name = "txtEmailNewCust"
        Me.txtEmailNewCust.Size = New System.Drawing.Size(100, 22)
        Me.txtEmailNewCust.TabIndex = 9
        '
        'txtUsernameNewCust
        '
        Me.txtUsernameNewCust.Location = New System.Drawing.Point(146, 214)
        Me.txtUsernameNewCust.Name = "txtUsernameNewCust"
        Me.txtUsernameNewCust.Size = New System.Drawing.Size(100, 22)
        Me.txtUsernameNewCust.TabIndex = 10
        '
        'lblPasswordNewCustomer
        '
        Me.lblPasswordNewCustomer.AutoSize = True
        Me.lblPasswordNewCustomer.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPasswordNewCustomer.Location = New System.Drawing.Point(43, 251)
        Me.lblPasswordNewCustomer.Name = "lblPasswordNewCustomer"
        Me.lblPasswordNewCustomer.Size = New System.Drawing.Size(88, 18)
        Me.lblPasswordNewCustomer.TabIndex = 11
        Me.lblPasswordNewCustomer.Text = "Password"
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(146, 251)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(100, 22)
        Me.TextBox1.TabIndex = 12
        '
        'frmNewCustomerLogin
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(432, 450)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.lblPasswordNewCustomer)
        Me.Controls.Add(Me.txtUsernameNewCust)
        Me.Controls.Add(Me.txtEmailNewCust)
        Me.Controls.Add(Me.txtLastNameNewCust)
        Me.Controls.Add(Me.txtFirstNameNewCust)
        Me.Controls.Add(Me.btnCreateAccountCustomer)
        Me.Controls.Add(Me.lblUsernameNewCust)
        Me.Controls.Add(Me.lblEmailNewCustomer)
        Me.Controls.Add(Me.lblLastNameNewCust)
        Me.Controls.Add(Me.lblFirstNameNewCust)
        Me.Controls.Add(Me.pnlBlack)
        Me.Controls.Add(Me.pnlBlue)
        Me.Name = "frmNewCustomerLogin"
        Me.Text = "New Customer Login"
        Me.pnlBlue.ResumeLayout(False)
        Me.pnlBlue.PerformLayout()
        CType(Me.picLogo, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents pnlBlue As Panel
    Friend WithEvents picLogo As PictureBox
    Friend WithEvents pnlBlack As Panel
    Friend WithEvents lblNewCustomerAccount As Label
    Friend WithEvents lblFirstNameNewCust As Label
    Friend WithEvents lblLastNameNewCust As Label
    Friend WithEvents lblEmailNewCustomer As Label
    Friend WithEvents lblUsernameNewCust As Label
    Friend WithEvents btnCreateAccountCustomer As Button
    Friend WithEvents txtFirstNameNewCust As TextBox
    Friend WithEvents txtLastNameNewCust As TextBox
    Friend WithEvents txtEmailNewCust As TextBox
    Friend WithEvents txtUsernameNewCust As TextBox
    Friend WithEvents lblPasswordNewCustomer As Label
    Friend WithEvents TextBox1 As TextBox
End Class
