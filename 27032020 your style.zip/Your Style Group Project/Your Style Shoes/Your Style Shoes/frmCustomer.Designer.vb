﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmCustomer
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.picLogo = New System.Windows.Forms.PictureBox()
        Me.DateTimePicker1 = New System.Windows.Forms.DateTimePicker()
        Me.pnlCustomer = New System.Windows.Forms.Panel()
        Me.lblWelcome = New System.Windows.Forms.Label()
        Me.btnNewCustomer = New System.Windows.Forms.Button()
        Me.btnExistingCustomer = New System.Windows.Forms.Button()
        Me.pnlBlack = New System.Windows.Forms.Panel()
        CType(Me.picLogo, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlCustomer.SuspendLayout()
        Me.SuspendLayout()
        '
        'picLogo
        '
        Me.picLogo.BackColor = System.Drawing.Color.White
        Me.picLogo.Image = Global.Your_Style_Shoes.My.Resources.Resources.logo_your_style
        Me.picLogo.Location = New System.Drawing.Point(315, 141)
        Me.picLogo.Name = "picLogo"
        Me.picLogo.Size = New System.Drawing.Size(250, 220)
        Me.picLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.picLogo.TabIndex = 0
        Me.picLogo.TabStop = False
        '
        'DateTimePicker1
        '
        Me.DateTimePicker1.Location = New System.Drawing.Point(608, 157)
        Me.DateTimePicker1.Name = "DateTimePicker1"
        Me.DateTimePicker1.Size = New System.Drawing.Size(200, 22)
        Me.DateTimePicker1.TabIndex = 1
        '
        'pnlCustomer
        '
        Me.pnlCustomer.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.pnlCustomer.Controls.Add(Me.lblWelcome)
        Me.pnlCustomer.Location = New System.Drawing.Point(1, 0)
        Me.pnlCustomer.Name = "pnlCustomer"
        Me.pnlCustomer.Size = New System.Drawing.Size(613, 78)
        Me.pnlCustomer.TabIndex = 2
        '
        'lblWelcome
        '
        Me.lblWelcome.AutoSize = True
        Me.lblWelcome.Font = New System.Drawing.Font("Verdana", 19.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblWelcome.Location = New System.Drawing.Point(37, 19)
        Me.lblWelcome.Name = "lblWelcome"
        Me.lblWelcome.Size = New System.Drawing.Size(210, 40)
        Me.lblWelcome.TabIndex = 0
        Me.lblWelcome.Text = "Welcome! "
        '
        'btnNewCustomer
        '
        Me.btnNewCustomer.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnNewCustomer.Location = New System.Drawing.Point(49, 141)
        Me.btnNewCustomer.Name = "btnNewCustomer"
        Me.btnNewCustomer.Size = New System.Drawing.Size(208, 79)
        Me.btnNewCustomer.TabIndex = 3
        Me.btnNewCustomer.Text = "&New Customer"
        Me.btnNewCustomer.UseVisualStyleBackColor = True
        '
        'btnExistingCustomer
        '
        Me.btnExistingCustomer.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnExistingCustomer.Location = New System.Drawing.Point(49, 289)
        Me.btnExistingCustomer.Name = "btnExistingCustomer"
        Me.btnExistingCustomer.Size = New System.Drawing.Size(208, 88)
        Me.btnExistingCustomer.TabIndex = 4
        Me.btnExistingCustomer.Text = "&Existing Customer"
        Me.btnExistingCustomer.UseVisualStyleBackColor = True
        '
        'pnlBlack
        '
        Me.pnlBlack.BackColor = System.Drawing.Color.Black
        Me.pnlBlack.Location = New System.Drawing.Point(1, 75)
        Me.pnlBlack.Name = "pnlBlack"
        Me.pnlBlack.Size = New System.Drawing.Size(610, 13)
        Me.pnlBlack.TabIndex = 5
        '
        'frmCustomer
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(611, 450)
        Me.Controls.Add(Me.pnlBlack)
        Me.Controls.Add(Me.btnExistingCustomer)
        Me.Controls.Add(Me.btnNewCustomer)
        Me.Controls.Add(Me.pnlCustomer)
        Me.Controls.Add(Me.DateTimePicker1)
        Me.Controls.Add(Me.picLogo)
        Me.Name = "frmCustomer"
        Me.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Text = "Customer"
        CType(Me.picLogo, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlCustomer.ResumeLayout(False)
        Me.pnlCustomer.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents picLogo As PictureBox
    Friend WithEvents DateTimePicker1 As DateTimePicker
    Friend WithEvents pnlCustomer As Panel
    Friend WithEvents lblWelcome As Label
    Friend WithEvents btnNewCustomer As Button
    Friend WithEvents btnExistingCustomer As Button
    Friend WithEvents pnlBlack As Panel
End Class
