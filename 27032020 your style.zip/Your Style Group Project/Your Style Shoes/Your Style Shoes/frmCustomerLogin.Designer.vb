﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmCustomerLogin
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.pnlCustomer = New System.Windows.Forms.Panel()
        Me.lblCustomerUsernameLogin = New System.Windows.Forms.Label()
        Me.lblCustomerPasswordLogin = New System.Windows.Forms.Label()
        Me.txtCustomerUsernameLogin = New System.Windows.Forms.TextBox()
        Me.txtCustomerPasswordLogin = New System.Windows.Forms.TextBox()
        Me.pnlBlackCustomer = New System.Windows.Forms.Panel()
        Me.grpCustomerLogin = New System.Windows.Forms.GroupBox()
        Me.picLogoCustomer = New System.Windows.Forms.PictureBox()
        Me.BindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        Me.pnlCustomer.SuspendLayout()
        Me.grpCustomerLogin.SuspendLayout()
        CType(Me.picLogoCustomer, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'pnlCustomer
        '
        Me.pnlCustomer.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.pnlCustomer.Controls.Add(Me.picLogoCustomer)
        Me.pnlCustomer.Location = New System.Drawing.Point(0, 0)
        Me.pnlCustomer.Name = "pnlCustomer"
        Me.pnlCustomer.Size = New System.Drawing.Size(383, 104)
        Me.pnlCustomer.TabIndex = 0
        '
        'lblCustomerUsernameLogin
        '
        Me.lblCustomerUsernameLogin.AutoSize = True
        Me.lblCustomerUsernameLogin.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCustomerUsernameLogin.Location = New System.Drawing.Point(50, 40)
        Me.lblCustomerUsernameLogin.Name = "lblCustomerUsernameLogin"
        Me.lblCustomerUsernameLogin.Size = New System.Drawing.Size(92, 18)
        Me.lblCustomerUsernameLogin.TabIndex = 1
        Me.lblCustomerUsernameLogin.Text = "Username"
        '
        'lblCustomerPasswordLogin
        '
        Me.lblCustomerPasswordLogin.AutoSize = True
        Me.lblCustomerPasswordLogin.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCustomerPasswordLogin.Location = New System.Drawing.Point(50, 78)
        Me.lblCustomerPasswordLogin.Name = "lblCustomerPasswordLogin"
        Me.lblCustomerPasswordLogin.Size = New System.Drawing.Size(88, 18)
        Me.lblCustomerPasswordLogin.TabIndex = 2
        Me.lblCustomerPasswordLogin.Text = "Password"
        '
        'txtCustomerUsernameLogin
        '
        Me.txtCustomerUsernameLogin.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCustomerUsernameLogin.Location = New System.Drawing.Point(170, 32)
        Me.txtCustomerUsernameLogin.Name = "txtCustomerUsernameLogin"
        Me.txtCustomerUsernameLogin.Size = New System.Drawing.Size(127, 26)
        Me.txtCustomerUsernameLogin.TabIndex = 3
        '
        'txtCustomerPasswordLogin
        '
        Me.txtCustomerPasswordLogin.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCustomerPasswordLogin.Location = New System.Drawing.Point(170, 78)
        Me.txtCustomerPasswordLogin.Name = "txtCustomerPasswordLogin"
        Me.txtCustomerPasswordLogin.PasswordChar = Global.Microsoft.VisualBasic.ChrW(9679)
        Me.txtCustomerPasswordLogin.Size = New System.Drawing.Size(127, 26)
        Me.txtCustomerPasswordLogin.TabIndex = 4
        '
        'pnlBlackCustomer
        '
        Me.pnlBlackCustomer.BackColor = System.Drawing.Color.Black
        Me.pnlBlackCustomer.Location = New System.Drawing.Point(0, 97)
        Me.pnlBlackCustomer.Name = "pnlBlackCustomer"
        Me.pnlBlackCustomer.Size = New System.Drawing.Size(383, 18)
        Me.pnlBlackCustomer.TabIndex = 5
        '
        'grpCustomerLogin
        '
        Me.grpCustomerLogin.Controls.Add(Me.txtCustomerUsernameLogin)
        Me.grpCustomerLogin.Controls.Add(Me.txtCustomerPasswordLogin)
        Me.grpCustomerLogin.Controls.Add(Me.lblCustomerPasswordLogin)
        Me.grpCustomerLogin.Controls.Add(Me.lblCustomerUsernameLogin)
        Me.grpCustomerLogin.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grpCustomerLogin.Location = New System.Drawing.Point(21, 152)
        Me.grpCustomerLogin.Name = "grpCustomerLogin"
        Me.grpCustomerLogin.Size = New System.Drawing.Size(321, 135)
        Me.grpCustomerLogin.TabIndex = 6
        Me.grpCustomerLogin.TabStop = False
        Me.grpCustomerLogin.Text = "Login"
        '
        'picLogoCustomer
        '
        Me.picLogoCustomer.Image = Global.Your_Style_Shoes.My.Resources.Resources.logo_your_style
        Me.picLogoCustomer.Location = New System.Drawing.Point(3, 3)
        Me.picLogoCustomer.Name = "picLogoCustomer"
        Me.picLogoCustomer.Size = New System.Drawing.Size(100, 88)
        Me.picLogoCustomer.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.picLogoCustomer.TabIndex = 0
        Me.picLogoCustomer.TabStop = False
        '
        'BindingSource1
        '
        '
        'frmCustomerLogin
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(383, 343)
        Me.Controls.Add(Me.grpCustomerLogin)
        Me.Controls.Add(Me.pnlBlackCustomer)
        Me.Controls.Add(Me.pnlCustomer)
        Me.Name = "frmCustomerLogin"
        Me.Text = "Customer Login"
        Me.pnlCustomer.ResumeLayout(False)
        Me.grpCustomerLogin.ResumeLayout(False)
        Me.grpCustomerLogin.PerformLayout()
        CType(Me.picLogoCustomer, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents pnlCustomer As Panel
    Friend WithEvents picLogoCustomer As PictureBox
    Friend WithEvents lblCustomerUsernameLogin As Label
    Friend WithEvents lblCustomerPasswordLogin As Label
    Friend WithEvents txtCustomerUsernameLogin As TextBox
    Friend WithEvents txtCustomerPasswordLogin As TextBox
    Friend WithEvents pnlBlackCustomer As Panel
    Friend WithEvents grpCustomerLogin As GroupBox
    Friend WithEvents BindingSource1 As BindingSource
End Class
