﻿Partial Class Your_Style_DBDataSet1
    Partial Public Class tblCustomerDataTable
        Private Sub tblCustomerDataTable_ColumnChanging(sender As Object, e As DataColumnChangeEventArgs) Handles Me.ColumnChanging
            If (e.Column.ColumnName = Me.Customer_NameColumn.ColumnName) Then
                'Add user code here
            End If

        End Sub

    End Class
End Class
